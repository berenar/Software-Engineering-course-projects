package com.uib.ia.damesv1;

public class Cerca {

    private Game game;
    private GeneradorDeMoviments g = new GeneradorDeMoviments();
    private static int alfa = -999999;
    private static int beta = 999999;
    public static long nodes;
    public int millor_puntuacio = -Integer.MAX_VALUE;
    public static int [] millor_jugada = new int [2];

    public Cerca(Game game) {
        this.game = game;
    }

    Moviment avaluaTauler(Tauler t, int torn) {

        int millor_moviment = 0;
        int maxim = -99999;
        int valor;
        int nivell = 1;    //profunditat

        Moviments movs = g.generaMovimentsPeces(t, torn);
        if (movs.num_moviments == 1){ return movs.moviments[0];}
        else if (movs.num_moviments==0){return null;}

        for (int i = 0; i < movs.num_moviments; i++) {
            Tauler nou_tauler = game.simula_moviment(t, movs.moviments[i]);
            valor = minmax(nou_tauler, game.contrari(torn), nivell + 1, alfa, beta);
            if (valor > maxim) {
                maxim = valor;
                millor_moviment = i;
                millor_jugada[0] = movs.moviments[i].desti;
            }
        }
        return movs.moviments[millor_moviment];
    }
    /*
    Algoritme minmax amb poda alfa-beta
     */
    private int minmax(Tauler t, int torn, int nivell, int alpha, int beta) {
        int valor;
        int millor_desti;
        Moviments movs = g.generaMovimentsPeces(t, torn);
        Moviments movsr = g.generaMovimentsPeces(t, game.contrari(torn));
        if (movs.num_moviments == 0) {
            return -999999;
        }
        if (movsr.num_moviments == 0) {
            return 999999;
        }
        if (nivell >= 2) {
            return valorPosicio(t, movs, movsr);
        }

        millor_puntuacio = -999999;

        millor_desti = 0;
        for (int i = 0; i < movs.num_moviments; i++) {

            Tauler nou_tauler = game.simula_moviment(t, movs.moviments[i]);
            valor = -minmax(nou_tauler, game.contrari(torn), nivell + 1, -beta, -alpha);
            if (valor > millor_puntuacio) {
                millor_puntuacio = valor;
            }
            if (valor >= beta) {
                return millor_puntuacio;
            }
            if (valor > alpha) {
                alpha = valor;
            }
        }
        millor_jugada[nivell] = millor_desti;
        return millor_puntuacio;
    }

    /*
    Retorna el millor moviment a fer
     */
    private int valorPosicio(Tauler t, Moviments movs1, Moviments movs2) {
        int negres = 0;
        int blanques = 0;
        int millor_moviment_blanques = 0;
        int millor_moviment_negres = 0;
        int punts = 0;
        int puntsTotals = 0;

        for (int i = 0; i < movs1.num_moviments; i++) {

            Tauler ta = game.simula_moviment(t, movs1.moviments[i]);
            for (int j = 0; j < ta.casella.length; j++) {
                for (int k = 0; k < ta.casella[j].length; k++) {
                    if (ta.casella[j][k] == Game.NEGRA) {
                        negres++;
                    } if (ta.casella[j][k] == Game.BLANCA) {
                        blanques++;
                    }
                }
            }
            if (movs1.moviments[i].salt) {
                punts += 10;
            } if (movs1.moviments[i].dama) {
                punts += 3;
            }

            if (millor_moviment_blanques < punts) {
                millor_moviment_blanques = punts;
            }
            blanques = 0;
            punts = 0;
            negres = 0;

        }

        for (int i = 0; i < movs2.num_moviments; i++) {

            Tauler ta = game.simula_moviment(t, movs2.moviments[i]);
            for (int j = 0; j < ta.casella.length; j++) {
                for (int k = 0; k < ta.casella[j].length; k++) {
                    if (ta.casella[j][k] == Game.NEGRA) {
                        negres++;
                    } if (ta.casella[j][k] == Game.BLANCA) {
                        blanques++;
                    }
                }
            }
            if (movs2.moviments[i].salt) {
                punts += 10;
            } if (movs2.moviments[i].dama) {
                punts += 3;
            }
            if (millor_moviment_negres < punts) {
                millor_moviment_negres = punts;
            }
            negres = 0;
            punts = 0;
            blanques = 0;
        }
        //funció heurística
        //https://youtu.be/kdHelXCWF8c

        return (millor_moviment_blanques - millor_moviment_negres);

    }
}