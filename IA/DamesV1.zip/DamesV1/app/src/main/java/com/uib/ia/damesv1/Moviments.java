package com.uib.ia.damesv1;

// Guarda una taula de moviments
// a més de tots els moviments legals
// ens diu quants de moviments hi ha "num_moviments"
// i quants d'ells són captures "numSalts"

class Moviments
{
    int num_moviments;
    int numSalts;
    Moviment[] moviments = new Moviment[GeneradorDeMoviments.MAXMOVIMENTS];

    public Moviments()
    {
        inicia();
        for (int i=0; i<GeneradorDeMoviments.MAXMOVIMENTS;i++)
            moviments[i] = new Moviment(-1,-1);
    }

    public void inicia()
    {
        num_moviments = 0;
        numSalts = 0;
    }
}